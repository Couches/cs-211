public class Square extends Rectangle
{
    public Square()
    {
        super();
    }

    public Square(Point topLeft, int baseLength)
    {
        super(topLeft, new Point(topLeft.getX() + baseLength, topLeft.getY() - baseLength));
    }

    public String getType()
    {
        return "Square";
    }
}

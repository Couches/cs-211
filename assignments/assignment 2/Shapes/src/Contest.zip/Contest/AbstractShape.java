public abstract class AbstractShape implements Shape
{
    public int compareTo(Shape other)
    {
        double areaDifference = getArea() - other.getArea();
        double perimeterDifference = getPerimeter() - other.getPerimeter();
        
        if (areaDifference > 0) return 1;
        if (areaDifference < 0) return -1;

        if (perimeterDifference > 0) return 1;
        if (perimeterDifference < 0) return -1;

        return getType().compareTo(other.getType());
    }
}

public class Rectangle extends AbstractShape
{
    private Point topLeft;
    private Point bottomRight;

    public Rectangle()
    {
        this(new Point(), new Point());
    }

    public Rectangle(Point topLeft, Point bottomRight)
    {
        this.topLeft = topLeft;
        this.bottomRight = bottomRight;

        
    }

    public String getType()
    {
        return "Rectangle";
    }

    public double getPerimeter()
    {
        double base = Math.abs(topLeft.getX() - bottomRight.getX());
        double height = Math.abs(topLeft.getY() - bottomRight.getY());

        return (base * 2) + (height * 2);
    }

    public double getArea()
    {
        double base = Math.abs(topLeft.getX() - bottomRight.getX());
        double height = Math.abs(topLeft.getY() - bottomRight.getY());

        return base * height;
    }

    public String toString()
    {
        return String.format("{Type=%s, TopLeft=%s, BottomRight=%s}", 
                        getType(), topLeft.toString(), bottomRight.toString());
    }
}

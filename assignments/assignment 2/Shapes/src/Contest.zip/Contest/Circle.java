public class Circle extends AbstractShape
{
    private Point center;
    private int radius;

    public Circle()
    {
        this(new Point(), 0);
    }

    public Circle(Point center, int radius)
    {
        this.center = center;
        this.radius = radius;
    }

    public String getType() {
        return "Circle";
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    public double getArea() {
        return Math.PI * Math.pow(radius, 2);
    }
    
    public String toString()
    {
        return String.format("{Type=%s, Center=%s, Radius=%d}", 
                        getType(), center.toString(), radius);
    }
}

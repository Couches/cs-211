Robert De Lappe

Estimated 2-3 hours spend on assignment

No known problems, besides not being able to create helper methods without errors.

I have no additional questions about the assignment.
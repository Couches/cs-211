Robert De Lappe

Estimated 3-4 hours spent on assignment

Known problem:
Program only reads top and left hints, so if bottom and right hints are invalid, the program won't catch them.

No questions about the assignment.
